package com.example.newdemo;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;

public class User {
    @NotEmpty(message = "Имя не может быть пустым")
    private String name;

    @Min(value = 18, message = "Возраст должен быть больше 18 лет")
    private int age;

    public User() { }

    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
