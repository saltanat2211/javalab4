package com.example.newdemo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/books")
public class BookController {

    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> addBook(@RequestBody Book book) {
        Map<String, Object> response = new HashMap<>();
        response.put("title", book.getTitle());
        response.put("author", book.getAuthor());
        response.put("status", "received");
        return ResponseEntity.ok(response);
    }
}
